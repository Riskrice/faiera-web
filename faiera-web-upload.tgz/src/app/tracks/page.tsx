import { redirect } from 'next/navigation'

export default function TracksPage() {
    redirect('/explore?type=track')
}
